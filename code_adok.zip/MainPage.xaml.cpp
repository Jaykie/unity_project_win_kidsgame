﻿//
// MainPage.xaml.cpp
// Implementation of the MainPage class.
//

#include "pch.h"
#include "MainPage.xaml.h"

using namespace kidsgame;

using namespace Platform;
using namespace Windows::Foundation;
using namespace Windows::Foundation::Collections;
using namespace Windows::UI::Xaml;
using namespace Windows::UI::Xaml::Controls;
using namespace Windows::UI::Xaml::Controls::Primitives;
using namespace Windows::UI::Xaml::Data;
using namespace Windows::UI::Xaml::Input;
using namespace Windows::UI::Xaml::Media;
using namespace Windows::UI::Xaml::Navigation;
using namespace Microsoft::Advertising::WinRT::UI;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

MainPage::MainPage()
{
	InitializeComponent();
}


void MainPage::CreateAdControl_Click(Object^ sender, RoutedEventArgs^ e)
{
	auto button = safe_cast<Button^>(sender);
	button->IsEnabled = false;

	// Programatically create an ad control. This must be done from the UI thread.

	auto adControl = ref new AdControl();

	// Set the application id and ad unit id
	// The application id and ad unit id can be obtained from Dev Center.
	// See "Monetize with Ads" at https ://msdn.microsoft.com/en-us/library/windows/apps/mt170658.aspx
	adControl->ApplicationId = L"d25517cb-12d4-4699-8bdc-52040c712cab";
	adControl->AdUnitId = L"10043134";

	// Set the dimensions
	adControl->Width = 600;
	adControl->Height = 100 ;

	// Add event handlers if you want
	adControl->ErrorOccurred += ref new EventHandler<AdErrorEventArgs^>(this, &MainPage::OnErrorOccurred);
	adControl->AdRefreshed += ref new EventHandler<RoutedEventArgs^>(this, &MainPage::OnAdRefreshed);

	// Add the ad control to the page
	auto parent = safe_cast<Panel^>(button->Parent);
	parent->Children->Append(adControl);
}


// This is an error handler for the ad control.
void MainPage::OnErrorOccurred(Object^ sender, AdErrorEventArgs^ e)
{
	//rootPage->NotifyUser("An error occurred. " + e->ErrorCode.ToString() + ": " + e->ErrorMessage, NotifyType::ErrorMessage);
}

// This is an event handler for the ad control. It's invoked when the ad is refreshed.
void MainPage::OnAdRefreshed(Object^ sender, RoutedEventArgs^ e)
{
	// We increment the ad count so that the message changes at every refresh.
	//adCount++;
	//rootPage->NotifyUser("Advertisement #" + adCount.ToString(), NotifyType::StatusMessage);
}

